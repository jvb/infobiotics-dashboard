#####################################################
A Model of the Lactose Operon in *Escherichia coli*
#####################################################

A model of the lactose operon in Escherichia coli was used to illustrate the Infobiotics Workbench in the `Plant Bioinformatics, Systems and Synthetic Biology Summer School <http://lobelia.cs.nott.ac.uk/plantsummerschool/>`_

The files necessary to run this example are available `here <http://www.infobiotic.org/downloads/models/lacOperonModel.zip>`_. 
