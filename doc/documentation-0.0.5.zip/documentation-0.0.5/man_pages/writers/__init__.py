# $Id: __init__.py 4775 2006-10-21 16:34:21Z grubert $
# Author: David Goodger <goodger@python.org>
# Copyright: This module has been placed in the public domain.
